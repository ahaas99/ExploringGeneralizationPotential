import NavBar from "../../components/NavBar"


function Research() {
  return (
    <>
    <NavBar />

    </>
  );
}


export default Research;