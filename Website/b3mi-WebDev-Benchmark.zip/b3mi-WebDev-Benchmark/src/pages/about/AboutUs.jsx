import NavBar from "../../components/NavBar";


function AboutUs() {
  return (
    <>
    <NavBar />

    </>
  );
}


export default AboutUs;