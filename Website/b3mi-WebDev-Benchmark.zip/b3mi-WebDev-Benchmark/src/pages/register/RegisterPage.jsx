import NavBar from "../../components/NavBar";
import RegisterForm from "./RegisterForm";


function Register() {
  return (
    <>
    <NavBar/>
    <RegisterForm/>

    </>
  );
}


export default Register;