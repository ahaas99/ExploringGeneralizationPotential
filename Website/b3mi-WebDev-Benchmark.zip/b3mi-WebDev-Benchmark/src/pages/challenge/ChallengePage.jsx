import NavBar from "../../components/NavBar";


function Benchmark() {
  return (
    <>
    <NavBar />

    </>
  );
}


export default Benchmark;