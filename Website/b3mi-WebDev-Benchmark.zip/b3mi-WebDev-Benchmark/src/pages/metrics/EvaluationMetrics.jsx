import NavBar from "../../components/NavBar"


function EvaluationMetrics() {
  return (
    <>
    <NavBar />

    </>
  );
}


export default EvaluationMetrics;